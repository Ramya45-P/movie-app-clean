from pydantic import BaseModel

class WatchlistCreate(BaseModel):
    movie_id: int


class WatchlistResponse(BaseModel):
    id: int
    movie_id: int
    user_id: int

    class Config:
        from_attributes = True